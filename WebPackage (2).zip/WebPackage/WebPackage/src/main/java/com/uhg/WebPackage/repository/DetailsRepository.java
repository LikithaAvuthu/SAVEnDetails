package com.uhg.WebPackage.repository;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.uhg.WebPackage.model.Details;


public interface DetailsRepository {
	
	public String readAllDetails();
	public void save(Details details);
	 
	//public Details get(String appName);
	public void delete(String appName);
	public String get(String appName);

	

}
