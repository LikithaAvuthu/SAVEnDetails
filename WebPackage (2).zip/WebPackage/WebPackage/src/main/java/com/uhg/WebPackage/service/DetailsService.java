package com.uhg.WebPackage.service;


import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;



import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.uhg.WebPackage.model.Details;
import com.uhg.WebPackage.repository.DetailsRepository;


@Service
@Transactional
public class DetailsService implements DetailsRepository{

	
public String readAllDetails() {
		
		// TODO Auto-generated method stub
		StringBuilder str = new StringBuilder();
		XSSFWorkbook myExcelBook;
		try {
			myExcelBook = new XSSFWorkbook(new FileInputStream("C:\\Users\\alikitha\\Downloads\\WebPackage\\WebPackage\\target\\input.xlsx"));
			String sheetName = myExcelBook.getSheetName(0);
		    XSSFSheet myExcelSheet = myExcelBook.getSheet(sheetName);
		
		    // row and columns    
		    XSSFRow row;
		    XSSFCell cells;

		    int rowCount = myExcelSheet.getLastRowNum();
		    int colCount = myExcelSheet.getRow(0).getLastCellNum();

		    // get each row details
		    for(int r = 0; r < 6; r++) {
		    	row = myExcelSheet.getRow(r);
		    	if(row.getPhysicalNumberOfCells() == 0){
	    		break;
		    	}
		    	if(row.getCell(5).toString().equals("Win")) {
		    	for(int c = 0; c < colCount; c++) {
	    		cells  = row.getCell(c);
	    
	    		
	    		if(cells.getCellType()==CellType.BLANK) {
	    			break;
	    		}
	    			
	    		String cellval = cells.toString()+"\t";
	            str.append(cellval+"\n");
	    		System.out.println(str);
		    	}
	            }
	    	}
		
		myExcelBook.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return str.toString();
	
	}

	
	public void save(Details details) {
		// TODO Auto-generated method stub
		StringBuilder str = new StringBuilder();
		XSSFWorkbook myExcelBook;
		try {
			myExcelBook = new XSSFWorkbook(new FileInputStream("input.xlsx"));
			String sheetName = myExcelBook.getSheetName(0);
		    XSSFSheet myExcelSheet = myExcelBook.getSheet(sheetName);
		
		    // row and columns    
		    XSSFRow row;
		    XSSFCell cells;

		    int rowCount = myExcelSheet.getLastRowNum();
		    row=myExcelSheet.createRow(rowCount+1);
		    cells=row.createCell(0);
		    cells.setCellValue("Junk");
		    
		    System.out.println("Afetr row creation ");
		    
		  	myExcelBook.close();
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch blocks
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
	}

	public void delete(String appName) {
		// TODO Auto-generated method stub
		StringBuilder str = new StringBuilder();
		XSSFWorkbook myExcelBook;
		try {
			FileInputStream file=new FileInputStream("input.xlsx");
			myExcelBook = new XSSFWorkbook(file);
			String sheetName = myExcelBook.getSheetName(0);
		    XSSFSheet myExcelSheet = myExcelBook.getSheet(sheetName);
		
		    // row and columns    
		    XSSFRow row;
		    XSSFCell cells;

		    int rowCount = myExcelSheet.getLastRowNum();
		    int colCount = myExcelSheet.getRow(0).getLastCellNum();
		    for(int r = 0; r < 6; r++) {
		    	row = myExcelSheet.getRow(r);
		    	if(row.getPhysicalNumberOfCells() == 0){
	    		break;
		    	}
		    	
		    	if(row.getCell(0).toString().equals(appName)) {
		    		System.out.println("delete");
		    		System.out.println("Values:"+row.toString());
		    		myExcelSheet.removeRow(row);
		    		
		    	
		    	/*for(int c = 0; c < colCount; c++) {
		    		
	    		cells  = row.getCell(c);
	    		System.out.println("Cell Values:"+cells.toString());
	    		row.removeCell(cells);
	    		
	    		
		    	}*/
	           }
		    }
		  	myExcelBook.close();
		  	file.close();
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
	}

	public String get(String appName) {
		// TODO Auto-generated method stub
		StringBuilder str = new StringBuilder();
		XSSFWorkbook myExcelBook;
		try {
			myExcelBook = new XSSFWorkbook(new FileInputStream("input.xlsx"));
			String sheetName = myExcelBook.getSheetName(0);
		    XSSFSheet myExcelSheet = myExcelBook.getSheet(sheetName);
		
		    // row and columns    
		    XSSFRow row;
		    XSSFCell cells;

		    int rowCount = myExcelSheet.getLastRowNum();
		    int colCount = myExcelSheet.getRow(0).getLastCellNum();

		    // get each row details
		    for(int r = 0; r < 6; r++) {
		    	row = myExcelSheet.getRow(r);
		    	if(row.getPhysicalNumberOfCells() == 0){
	    		break;
		    	}
		    	if(row.getCell(0).toString().equals(appName)) {
		    	for(int c = 0; c < colCount; c++) {
	    		cells  = row.getCell(c);
	    
	    		
	    		if(cells.getCellType()==CellType.BLANK) {
	    			break;
	    		}
	    			
	    		String cellval = cells.toString()+"\t";
	            str.append(cellval+"\n");
	    		System.out.println(str);
		    	}
	           }
		    }
		  	myExcelBook.close();
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		return str.toString();

		}
		
	
}
