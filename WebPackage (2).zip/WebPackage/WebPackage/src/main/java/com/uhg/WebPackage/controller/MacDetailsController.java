package com.uhg.WebPackage.controller;

import org.springframework.beans.factory.annotation.*;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.uhg.WebPackage.exception.RecordNotFoundException;
import com.uhg.WebPackage.model.Details;
import com.uhg.WebPackage.repository.DetailsRepository;
import com.uhg.WebPackage.service.DetailsService;

import java.util.List;
import java.util.NoSuchElementException;

@RestController
@RequestMapping("/Mac")
public class MacDetailsController {
	
	@Autowired
	private DetailsService service;
	@RequestMapping("/")
	public String welcome() {
		return "welcome to ExcelController";
	}
	
	
	//1)Get “/Win/getAllApp” -&gt;Return list of all Applications from excel.
	@GetMapping("/details")
	public String Details() {
		System.out.println("inside /details :1");
	    return service.readAllDetails();
	}
	
	//2)Get “/Win/getApp/{AppName} Assume that rest API call receive path param as AppName and based
	//on AppName return the entire record matching with the AppName.
	@GetMapping("/details/{name}")
	public String get(@PathVariable("name") String appName) {
		System.out.println("inside /details/{name} :2");
		try {
	        String str = service.get(appName);
	        return str;
	    } catch (NoSuchElementException e) {
	        return HttpStatus.NOT_FOUND.toString();
	    }      
	}
}
